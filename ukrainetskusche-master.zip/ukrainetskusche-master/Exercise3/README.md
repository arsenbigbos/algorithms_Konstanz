- Navigate into the src folder inside the VertexCover folder
- execute: ```javac .\test\TestVC.java```  
  this compiles all the java files
- to run the whole test case, execute: ```java .\test\RunWholeTest.java```  
  the resulting file will appear in the results folder
- to execute single functions, use: ```java .\test\TestVC.java type input output```
  with the parameters:
  - ```input```: the input file, always mandatory
  - ```output```: the output file, can be omitted for some actions
  - ```type```: the type of action you want to perform
    - ```i```: execute the improved exact algorithm using the data of the input file to build the graph and writing the solution to the output file, if the 3rd argument is present. The solution size and the running time are printed to the console.
    - ```e```: execute the unimproved exact algorithm using the data of the input file to build the graph and writing the solution to the output file, if the 3rd argument is present. The solution size and the running time are printed to the console.
    - ```a```: execute the 2-APX algorithm using the data of the input file to build the graph, the third argument is ignored. The solution size and the running time are printed to the console.
    - ```v```: validate the vertex cover given in output using the graph in input. The result is printed to the console
  - example: ```java .\test\TestVC.java i "vc-exact_002.gr" "result.vc"```