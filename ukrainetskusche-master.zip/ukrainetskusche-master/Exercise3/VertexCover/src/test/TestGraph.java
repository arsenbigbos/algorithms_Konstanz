package test;

import main.Reader;

import java.io.IOException;
import java.util.*;

/**
 * graph class for test purposes, only used by validate to confirm whether a vertex cover is valid
 */
public class TestGraph {
    private final TestNode[] nodes;
    private Set<Edge> edges;

    public TestGraph(String file) throws IOException {
        this(Reader.read(file, 'c', 'p'));
    }

    public TestGraph(List<String> data) {
        int n = Integer.parseInt(data.get(0));
        int m = Integer.parseInt(data.get(1));

        nodes = new TestNode[n];
        edges = new LinkedHashSet<>(m);

        for (int i = 2; i < data.size() ; i++) {
            String[] vpr = data.get(i).split("\\s+");
            int s, t;
            s = Integer.parseInt(vpr[0]) - 1;
            t = Integer.parseInt(vpr[1]) - 1;
            Edge edge = new Edge(s, t);

            if (nodes[s] == null) {
                nodes[s] = new TestNode(s);
            }
            if (nodes[t] == null) {
                nodes[t] = new TestNode(t);
            }
            nodes[s].edges.add(edge);
            nodes[t].edges.add(edge);

            edges.add(edge);
        }
    }

    public boolean isEmpty() {
        return edges.isEmpty();
    }

    /**
     * Removes a node and its incident edges from the graph
     * @param i id of the node
     * @return the removed node
     */
    public TestNode removeIncEdges(int i) {
        for (Edge edge : nodes[i].edges) {
            edges.remove(edge);
            int other = edge.s == i ? edge.t : edge.s;
            if (other != i) {
                nodes[other].edges.remove(edge);
            }
        }

        TestNode vertex = nodes[i];
        nodes[i] = null;
        return vertex;
    }
}
