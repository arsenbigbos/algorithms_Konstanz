package test;

import java.util.LinkedHashSet;
import java.util.Set;

/**
 * node class for the test graph. Stores its incident edges
 */
public class TestNode {
    int id;
    Set<Edge> edges = new LinkedHashSet<>();

    public TestNode(int ID) {
        this.id = ID;
    }

    public int degree() {
        return edges.size();
    }

    @Override
    public String toString() {
        return "" + id;
    }
}
