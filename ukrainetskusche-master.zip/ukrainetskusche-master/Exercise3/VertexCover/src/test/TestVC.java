package test;

import main.Graph;
import main.Reader;

import java.io.IOException;
import java.util.LinkedList;
import java.util.List;

public class TestVC {
    public static void main(String[] args) throws IOException {
        String type = args[0];
        String input = args[1];

        int maxK;
        List<Integer> cover;

        long start, end;
        int maxTimeMinutes = 4;

        if (type.equals("i")) {
            List<String> data = Reader.read(input, 'c', 'p');
            Graph g1 = new Graph(data);
            Graph g2 = new Graph(data);

            cover = g1.vcAPX();
            maxK = cover.size();

            start = System.currentTimeMillis();
            cover = g2.vcImproved(maxK, maxTimeMinutes);
            end = System.currentTimeMillis();
            System.out.println("Improved Exact solution size: " + cover.size());
            System.out.println("Improved Exact running time: " + (end - start));

            if (args.length == 3) {
                Reader.write(args[2], cover, g2.n());
            }
        } else if (type.equals("e")) {
            List<String> data = Reader.read(input, 'c', 'p');
            Graph g1 = new Graph(data);
            Graph g2 = new Graph(data);

            cover = g1.vcAPX(new LinkedList<>());
            maxK = cover.size();

            start = System.currentTimeMillis();
            cover = g2.vcExact(maxK, maxTimeMinutes);
            end = System.currentTimeMillis();
            System.out.println("Improved Exact solution size: " + cover.size());
            System.out.println("Improved Exact running time: " + (end - start));

            if (args.length == 3) {
                Reader.write(args[2], cover, g2.n());
            }
        } else if (type.equals("a")) {
            List<String> data = Reader.read(input, 'c', 'p');
            Graph g1 = new Graph(data);

            start = System.currentTimeMillis();
            cover = g1.vcAPX(new LinkedList<>());
            end = System.currentTimeMillis();
            maxK = cover.size();
            System.out.println("APX solution size: " + maxK);
            System.out.println("APX running time: " + (end - start));
        } else if (type.equals("v")) {
            System.out.println("Valid VC: " + RunWholeTest.validate(input, args[2]));
        } else {
            System.out.println("Wrong type");
        }
    }
}
