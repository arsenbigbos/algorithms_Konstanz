package test;

import java.util.LinkedList;
import java.util.List;

/**
 * stores the data to be measured
 */
public class VCData {
    public int[] apxSolutionSize = new int[200];
    public long[] apxRunningTimes = new long[200];
    public int[] exactSolutionSize = new int[200];
    public long[] exactRunningTimes = new long[200];
    public int counter1 = 0;
    public int counter2 = 0;
    public List<Double> ratios = new LinkedList<>();
}
