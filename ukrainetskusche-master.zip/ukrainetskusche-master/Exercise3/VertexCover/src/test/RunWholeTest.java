package test;

import main.Graph;
import main.Reader;

import java.io.IOException;
import java.util.LinkedList;
import java.util.List;

/**
 * runs the complete test case
 */
public class RunWholeTest {
    public static void main(String[] args) throws IOException {
        String graphStart = "../data/vc-exact_";
        String results = "../results/dataVC.vc";

        int maxK;
        List<Integer> cover;

        VCData vcData = new VCData();
        long start, end;
        int maxTimeMinutes = 4;
        for (int i = 1; i <= 200; i++) {
            List<String> data = Reader.read(graphStart + String.format("%03d", i) + ".gr", 'c', 'p');
            Graph g1 = new Graph(data);
            Graph g2 = new Graph(data);
            TestGraph t1 = new TestGraph(data);
            TestGraph t2 = new TestGraph(data);

            start = System.currentTimeMillis();
            cover = g1.vcAPX(new LinkedList<>());
            end = System.currentTimeMillis();
            maxK = cover.size();
            vcData.apxSolutionSize[i - 1] = cover.size();
            vcData.apxRunningTimes[i - 1] = end - start;

            start = System.currentTimeMillis();
            cover = g2.vcExact(maxK, maxTimeMinutes);
            end = System.currentTimeMillis();
            vcData.exactSolutionSize[i - 1] = cover.size();
            vcData.exactRunningTimes[i - 1] = end - start;
            System.out.println("Exact " + i + ": " + cover.size());
            boolean exactSolution = validate(t2, cover);
            System.out.println(exactSolution);

            if (!exactSolution) {
                vcData.counter1++;
            } else if (vcData.apxSolutionSize[i - 1] == vcData.exactSolutionSize[i - 1]) {
                vcData.counter2++;
            } else {
                vcData.ratios.add((double) vcData.apxSolutionSize[i - 1] / vcData.exactSolutionSize[i - 1]);
            }
        }

        Reader.write(results, vcData);
    }

    /**
     * validates a vertex cover in vcFile for the graph in graphFile
     * @param graphFile
     * @param vcFile
     * @return whether the vertex cover is valid or not
     * @throws IOException
     */
    public static boolean validate(String graphFile, String vcFile) throws IOException {
        TestGraph g = new TestGraph(graphFile);
        List<String> coverS = Reader.read(vcFile, 'c', 's');
        coverS.remove(0);
        coverS.remove(0);
        List<Integer> cover = new LinkedList<>();
        for (String s : coverS) {
            cover.add(Integer.valueOf(s));
        }
        return validate(g, cover);
    }

    public static boolean validate(TestGraph g, List<Integer> cover) {
        for (int node : cover) {
            if (node == -1) {
                return false;
            }
            g.removeIncEdges(node - 1);
        }
        return g.isEmpty();
    }
}
