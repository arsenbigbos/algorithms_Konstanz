package test;

public class Edge {
    int s, t;

    public Edge(int s, int t) {
        this.s = s;
        this.t = t;
    }

    public String toString() {
        return s + " " + t;
    }
}
