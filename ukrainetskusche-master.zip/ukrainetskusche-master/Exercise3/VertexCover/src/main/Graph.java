package main;

import java.io.IOException;
import java.util.*;

/**
 * the main class of this project. Contains methods for the 2-APX algorithm, the improved and the unimproved exact
 * algorithm
 */
public class Graph {
    private final Node[] nodes;
    private final TreeSet<Node> remainingNodes;

    public Graph(String file) throws IOException {
        this(Reader.read(file, 'c', 'p'));
    }

    public Graph(List<String> data) {
        int n = Integer.parseInt(data.get(0));
        int m = Integer.parseInt(data.get(1));

        nodes = new Node[n];
        remainingNodes = new TreeSet<>(Comparator.reverseOrder());

        for (int i = 2; i < data.size() ; i++) {
            String[] vpr = data.get(i).split("\\s+");
            int s, t;
            s = Integer.parseInt(vpr[0]) - 1;
            t = Integer.parseInt(vpr[1]) - 1;

            if (nodes[s] == null) {
                nodes[s] = new Node(s);
            }
            if (nodes[t] == null) {
                nodes[t] = new Node(t);
            }
            nodes[s].neighbors.add(nodes[t]);
            nodes[t].neighbors.add(nodes[s]);
        }

        for (Node node : nodes) {
            if (node != null) {
                remainingNodes.add(node);
            }
        }
    }

    public int n() {
        return nodes.length;
    }

    public boolean isEmpty() {
        return remainingNodes.isEmpty();
    }

    /**
     * executes the 2-APX algorithm with preprocessing
     * @return the computed cover
     */
    public List<Integer> vcAPX() {
        return vcAPX(preprocess(Integer.MAX_VALUE));
    }

    /**
     * executes the 2-APX algorithm, adding its solution to the given cover. This allows for preprocessing
     * @param cover the cover to start with
     * @return the given cover
     */
    public List<Integer> vcAPX(List<Integer> cover) {
        for (Node v : remainingNodes) {
            v = nodes[v.id];
            if (v == null || v.degree() == 0) {
                continue;
            }
            Node u = v.neighbors.iterator().next();
            removeNodeNoSet(u);
            removeNodeNoSet(v);
            cover.add(u.id + 1);
            cover.add(v.id + 1);
        }
        return cover;
    }

    /**
     * computes a set of nodes which need to be included in any vertex cover of the graph and removes those
     * nodes from the graph
     * @param maxK the maximum k the exact algorithm plans to use
     * @return the set of nodes
     */
    public List<Integer> preprocess(int maxK) {
        List<Integer> cover = new LinkedList<>();
        for (Node v : nodes) {
            if (v == null || v.degree() == 0) {
                continue;
            }

            if (v.degree() == 1) {
                Node u = v.neighbors.iterator().next();
                cover.add(u.id + 1);
                removeNode(u.id);
            } else if (v.degree() > maxK - cover.size()) {
                cover.add(v.id + 1);
                removeNode(v.id);
            } else if (v.neighbors.contains(v)) {
                cover.add(v.id + 1);
                removeNode(v.id);
            }
        }
        Node v;
        while (!remainingNodes.isEmpty() && (v = remainingNodes.last()).degree() == 1) {
            Node u = v.neighbors.iterator().next();
            cover.add(u.id + 1);
            removeNode(u.id);
        }
        return cover;
    }

    /**
     * Executes the improved exact algorithm.
     * starts at maxK, runs vcImproved and decreases k, until no solution is found, then returns the last computed
     * solution
     * @param maxK the k to start with
     * @param maxTimeMinutes time after which to abort
     * @return the vertex cover
     */
    public List<Integer> vcImproved(int maxK, int maxTimeMinutes) {
        long startTime = System.currentTimeMillis();
        long maxTime = startTime + maxTimeMinutes * 60_000L;
        List<Integer> preResult = preprocess(maxK);
        List<Integer> previousCover;
        List<Integer> cover = new LinkedList<>();

        int maxMax = 4000;
        int k = Math.min(maxMax + preResult.size(), maxK);
        do {
            previousCover = cover;
            cover = vcImproved(k, new LinkedList<>(preResult), maxTime);
            if (!cover.isEmpty() && cover.get(0) == -1) {
                return cover;
            }
            k--;
        } while (!cover.isEmpty());

        return previousCover;
    }

    /**
     * improved version of the exact algorithm (decision problem).
     * tries to find a vertex cover with size at most k
     * @param k
     * @param cover the cover to start with (to allow for preprocessing)
     * @param maxTime time after which to abort
     * @return the vertex cover
     */
    public List<Integer> vcImproved(int k, List<Integer> cover, long maxTime) {
        if (System.currentTimeMillis() > maxTime) {
            return List.of(-1);
        }
        if (cover.size() > k) {
            return new LinkedList<>();
        }
        if (remainingNodes.isEmpty()) {
            return cover;
        }
        if (cover.size() == k) {
            return new LinkedList<>();
        }

        Node v = remainingNodes.first();
        if (v.degree() <= 2) {
            return solveIfDeg2(cover, k - cover.size());
        }

        Node minNode = remainingNodes.last();
        if (minNode.degree() > k - cover.size()) {
            return new LinkedList<>();
        }
        if (minNode.degree() == remainingNodes.size() - 1) {
            System.out.println("complete graph");
            remainingNodes.forEach(u -> cover.add(u.id + 1));
            cover.remove(cover.size() - 1);
            return cover;
        }

        boolean noSplit = false;
        if (v.degree() > k - cover.size()) {
            noSplit = true;
        } else if (minNode.degree() == 1) {
            noSplit = true;
            v = minNode.neighbors.iterator().next();
        }

        // remove node itself
        removeNode(v.id);
        cover.add(v.id + 1);
        List<Integer> result = vcImproved(k, cover, maxTime);
        reinsertNode(v);
        if (!result.isEmpty()) {
            return result;
        }
        cover.remove(cover.size() - 1);

        if (noSplit) {
            return new LinkedList<>();
        }

        // remove neighbors
        List<Node> removedNodes = removeNeighbors(v);
        removedNodes.forEach(u -> cover.add(u.id + 1));
        result = vcImproved(k, cover, maxTime);
        reinsertNodes(removedNodes);
        if (!result.isEmpty()) {
            return result;
        }
        removedNodes.forEach(u -> cover.remove(cover.size() - 1));

        return new LinkedList<>();
    }

    /**
     * Executes the unimproved version of the exact algorithm
     * starts at maxK, runs vcExact and decreases k, until no solution is found, then returns the last computed
     * solution
     * @param maxK the k to start with
     * @param maxTimeMinutes time after which to abort
     * @return the vertex cover
     */
    public List<Integer> vcExact(int maxK, int maxTimeMinutes) {
        long startTime = System.currentTimeMillis();
        long maxTime = startTime + maxTimeMinutes * 60_000L;
        List<Integer> preResult = preprocess(maxK);
        List<Integer> previousCover;
        List<Integer> cover = new LinkedList<>();

        int maxMax = 4000;
        int k = Math.min(maxMax + preResult.size(), maxK);
        do {
            previousCover = cover;
            cover = vcExact(k, new LinkedList<>(preResult), maxTime);
            if (!cover.isEmpty() && cover.get(0) == -1) {
                return cover;
            }
            k--;
        } while (!cover.isEmpty());

        return previousCover;
    }

    /**
     * unimproved version of the exact algorithm (decision problem).
     * tries to find a vertex cover with size at most k
     * @param k
     * @param cover the cover to start with (to allow for preprocessing)
     * @param maxTime time after which to abort
     * @return the vertex cover
     */
    public List<Integer> vcExact(int k, List<Integer> cover, long maxTime) {
        if (System.currentTimeMillis() > maxTime) {
            return List.of(-1);
        }
        if (cover.size() > k) {
            return new LinkedList<>();
        }
        if (remainingNodes.isEmpty()) {
            return cover;
        }

        Node v = remainingNodes.first();
        if (v.degree() == 0) {
            return cover;
        }
        if (v.degree() <= 2) {
            return solveIfDeg2(cover, k - cover.size());
        }
        if (cover.size() == k) {
            return new LinkedList<>();
        }

        // remove node itself
        removeNode(v.id);
        cover.add(v.id + 1);
        List<Integer> result = vcExact(k, cover, maxTime);
        reinsertNode(v);
        if (!result.isEmpty()) {
            return result;
        }
        cover.remove(cover.size() - 1);

        // remove neighbors
        List<Node> removedNodes = removeNeighbors(v);
        removedNodes.forEach(u -> cover.add(u.id + 1));
        result = vcExact(k, cover, maxTime);
        reinsertNodes(removedNodes);
        if (!result.isEmpty()) {
            return result;
        }
        removedNodes.forEach(u -> cover.remove(cover.size() - 1));

        return new LinkedList<>();
    }

    /**
     * computes a vertex cover for the graph if every node has at most degree 2
     * @param cover the cover up until this point
     * @param k
     * @return the vertex cover. Empty if no cover with size k possible
     */
    public List<Integer> solveIfDeg2(List<Integer> cover, int k) {
        if (remainingNodes.size() > 3 * k) {
            return new LinkedList<>();
        }
        List<Node> result = new LinkedList<>();
        Iterator<Node> it = remainingNodes.descendingIterator();
        while (it.hasNext()) {
            Node v = nodes[it.next().id];
            if (v == null || v.degree() == 0) {
                continue;
            }
            if (result.size() >= k) {
                reinsertNodesNoSet(result);
                return new LinkedList<>();
            }
            if (v.degree() == 2) {
                result.add(v);
                removeNodeNoSet(v);
            } else {
                Node u = v.neighbors.iterator().next();
                result.add(u);
                removeNodeNoSet(u);
            }
        }
        reinsertNodesNoSet(result);
        result.forEach(v -> cover.add(v.id + 1));
        return cover;
    }

    /**
     * Removes the node from the neighbor set of its neighbors but not from any other set (like remainingNodes)
     * @param v
     */
    public void removeNodeNoSet(Node v) {
        if (v == null) {
            return;
        }
        for (Node u : v.neighbors) {
            if (u.id != v.id) {
                u.neighbors.remove(v);
            }
        }
        nodes[v.id] = null;
    }

    /**
     * reinserts the nodes into the neighbor set of their neighbors but not in any other set (like remainingNodes)
     * @param ns
     */
    public void reinsertNodesNoSet(List<Node> ns) {
        ListIterator<Node> it = ns.listIterator(ns.size());
        while (it.hasPrevious()) {
            reinsertNodeNoSet(it.previous());
        }
    }

    /**
     * reinserts the node into the neighbor set of its neighbors but not in any other set (like remainingNodes)
     * @param ns
     */
    public void reinsertNodeNoSet(Node v) {
        nodes[v.id] = v;
        for (Node u : v.neighbors) {
            // there could be loops
            if (u.id != v.id) {
                u.neighbors.add(v);
            }
        }
    }

    /**
     * removes the neighbors of the given node from the graph
     * @param v
     * @return the removed nodes
     */
    public List<Node> removeNeighbors(Node v) {
        return removeNeighbors(v, remainingNodes);
    }

    /**
     * removes the neighbors of the given node from the neighbor set of their neighbors and the given set of nodes
     * @param v
     * @param nodeSet
     * @return the removed nodes
     */
    public List<Node> removeNeighbors(Node v, Set<Node> nodeSet) {
        List<Integer> neighborIds = new LinkedList<>();
        for (Node u : v.neighbors) {
            neighborIds.add(u.id);
        }
        return removeNodes(neighborIds, nodeSet);
    }

    /**
     * removes the given nodes (by id) from the graph
     * @param is
     * @return the removed nodes
     */
    public List<Node> removeNodes(List<Integer> is) {
        return removeNodes(is, remainingNodes);
    }

    /**
     * removes the given nodes (by id) from the neighbor set of their neighbors and the given set of nodes
     * @param is
     * @param nodeSet the removed nodes
     * @return
     */
    public List<Node> removeNodes(List<Integer> is, Set<Node> nodeSet) {
        List<Node> removedNodes = new LinkedList<>();
        for (int i : is) {
            Node v = removeNode(i, nodeSet);
            if (v != null) {
                removedNodes.add(v);
            }
        }
        return removedNodes;
    }

    /**
     * reinserts the given nodes into the graph
     * @param vs
     */
    public void reinsertNodes(List<Node> vs) {
        reinsertNodes(vs, remainingNodes);
    }

    /**
     * reinserts the nodes into the neighbor set of their neighbors and the given set of nodes
     * @param vs
     * @param nodeSet
     */
    public void reinsertNodes(List<Node> vs, Set<Node> nodeSet) {
        ListIterator<Node> it = vs.listIterator(vs.size());
        while (it.hasPrevious()) {
            reinsertNode(it.previous(), nodeSet);
        }
    }

    /**
     * removes the node with the given id from the graph
     * @param i
     * @return the removed node
     */
    public Node removeNode(int i) {
        return removeNode(i, remainingNodes);
    }

    /**
     * removes the node with the given id from the neighbor set of its neighbors and from the given set of nodes
     * @param i
     * @param nodeSet
     * @return the removed node
     */
    public Node removeNode(int i, Set<Node> nodeSet) {
        if (nodes[i] == null) {
            return null;
        }
        nodeSet.remove(nodes[i]);
        for (Node u : nodes[i].neighbors) {
            if (u.id != i) {
                nodeSet.remove(u);
                u.neighbors.remove(nodes[i]);
                if (u.degree() != 0) {
                    nodeSet.add(u);
                }
            }
        }

        Node node = nodes[i];
        nodes[i] = null;
        return node;
    }

    /**
     * reinserts the node into the graph
     * @param v
     */
    public void reinsertNode(Node v) {
        reinsertNode(v, remainingNodes);
    }

    /**
     * reinserts the node into the neighbor set of its neighbors and the given set of nodes
     * @param v
     * @param nodeSet
     */
    public void reinsertNode(Node v, Set<Node> nodeSet) {
        nodes[v.id] = v;
        nodeSet.add(v);
        for (Node u : v.neighbors) {
            // there could be loops
            if (u.id != v.id) {
                nodeSet.remove(u);
                u.neighbors.add(v);
                nodeSet.add(u);
            }
        }
    }
}
