package main;

import test.VCData;

import java.io.*;
import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

/**
 * for reading and writing from and to files
 */
public class Reader {
    public static List<String> read(String fileName, char comment, char header) throws IOException {
        List<String> data = new ArrayList<>();

        try (BufferedReader reader = new BufferedReader(new FileReader(fileName))) {
            String line;
            while ((line = reader.readLine()) != null) {
                if (line.charAt(0) == comment) {
                    continue;
                }
                if (line.charAt(0) == header) {
                    String[] words = line.split("\\s+");
                    data.add(words[2]);
                    data.add(words[3]);
                } else {
                    data.add(line);
                }
            }
        }

        return data;
    }

    public static void write(String fileName, VCData data) throws IOException {
        try (BufferedWriter writer = new BufferedWriter(new FileWriter(fileName))) {
            writer.write("APX sizes: ");
            for (int size : data.apxSolutionSize) {
                writer.write(size + " ");
            }
            writer.newLine();

            writer.write("Exact sizes: ");
            for (int size : data.exactSolutionSize) {
                writer.write(size + " ");
            }
            writer.newLine();

            writer.newLine();

            writer.write("APX times: ");
            for (long time : data.apxRunningTimes) {
                writer.write(time + " ");
            }
            writer.newLine();

            writer.write("Exact times: ");
            for (long time : data.exactRunningTimes) {
                writer.write(time + " ");
            }
            writer.newLine();

            writer.write("Number of instances in class 1: " + data.counter1 + "\n");
            writer.write("Number of instances in class 2: " + data.counter2 + "\n");
            writer.write("Number of instances in class 3: " + data.ratios.size() + "\n");
            writer.write("Average ratio: " + data.ratios.stream().mapToDouble(x -> x).average().getAsDouble() + "\n");
            writer.write("Max ratio: " + Collections.max(data.ratios) + "\n");

        }
    }

    public static void write(String fileName, List<?> data, int nNodes) throws IOException {
        try (BufferedWriter writer = new BufferedWriter(new FileWriter(fileName))) {
            writer.write("s vc " + nNodes + " " + data.size() + "\n");
            for (Object datum : data) {
                writer.write(datum.toString() + "\n");
            }
        }
    }
}
