package main;

import java.util.*;

/**
 * node class for the normal graph class. Stores its neighbors
 */
public class Node implements Comparable<Node> {
    int id;
    Set<Node> neighbors = new LinkedHashSet<>();

    public Node(int ID) {
        this.id = ID;
    }

    public int degree() {
        return neighbors.size();
    }

    @Override
    public int compareTo(Node o) {
        if (this == o) {
            return 0;
        }
        if (degree() != o.degree()) {
            return Integer.compare(degree(), o.degree());
        }
        return Integer.compare(id, o.id);
    }

    @Override
    public String toString() {
        return "" + id;
    }
}
