To execute the test case, please just run the main method of the Tester class  
(simply open the project in Eclipse or Intellij or whatever you prefer)  
The respective files will be created inside the data folder