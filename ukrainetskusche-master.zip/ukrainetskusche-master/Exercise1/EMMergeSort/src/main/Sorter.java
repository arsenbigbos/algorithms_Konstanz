package main;

import java.io.*;
import java.nio.ByteBuffer;
import java.nio.IntBuffer;
import java.util.Arrays;
import java.util.Random;

public class Sorter {
    public static final int MIB_TO_B = 1024 * 1024;

    private int fileLength; // in blocks

    private LimitedStream in1;
    private LimitedStream in2;
    private DataOutputStream out;

    // Buffers
    private ByteBuffer inBuf1;
    private ByteBuffer inBuf2;
    private ByteBuffer outBuf;
    private final int M; // in Bytes
    private int B; // int Bytes

    public Sorter(int ramSizeInMiB) {
        M = ramSizeInMiB * MIB_TO_B;
    }

    public static void createRandomFile(String fileName, int fileSizeMiB, int ramSizeMiB) throws IOException {
        Random rand = new Random();
        byte[] byteArray = new byte[ramSizeMiB * MIB_TO_B];
        DataOutputStream out = new DataOutputStream(new BufferedOutputStream(new FileOutputStream(fileName)));

        for (int i = 0; i < fileSizeMiB / ramSizeMiB; i++) {
            rand.nextBytes(byteArray);
            out.write(byteArray);
        }

        byte[] remainder = new byte[(fileSizeMiB % ramSizeMiB) * MIB_TO_B];
        rand.nextBytes(remainder);
        out.write(remainder);

        out.close();
    }

    public int emMergeSort(String inFileName, String outFileName, int blockSizeInMiB) throws IOException {

        B = blockSizeInMiB * MIB_TO_B;

        File inFile = new File(inFileName);
        File outFile = new File(outFileName);
        File ogOutFile = outFile;

        fileLength = (int) (inFile.length() / B);
        int rounds = 1;

        openStreams(inFile, outFile);
        createInitialRuns();
        closeStreams();

        inBuf1 = ByteBuffer.allocate(B);
        inBuf2 = ByteBuffer.allocate(B);
        outBuf = ByteBuffer.allocate(B);

        int dataRunSize = M / B;

        File tmp;
        while (dataRunSize < fileLength) {
            rounds++;
            tmp = inFile;
            inFile = outFile;
            outFile = tmp;

            merge1Layer(inFile, outFile, dataRunSize);

            dataRunSize *= 2;
        }

        inFile.delete();
        outFile.renameTo(ogOutFile);

        return rounds;
    }

    private void merge1Layer(File inFile, File outFile, int dataRunSize) throws IOException {
        openStreams(inFile, outFile);
        in1.initialize(dataRunSize, B);
        in2.initialize(dataRunSize, B);

        // loop needs to run for every pair of data runs + 1 time, if there's only one data run left
        for (int i = 0; i < Math.ceil((float) fileLength / (2 * dataRunSize)); i++) {
            // skip n blocks to position in2 at beginning of the data run following the one processed by in1
            in2.skipNBlocks(dataRunSize);
            merge2Runs();
            in1.resetCounter();
            in2.resetCounter();
            // skip over the data run which was processed by in2
            in1.skipNBlocks(dataRunSize);
        }
        closeStreams();
    }

    /**
     * merge 2 whole data runs and write the result to memory
     * @throws IOException
     */
    private void merge2Runs() throws IOException {
        inBuf1.clear();
        inBuf2.clear();
        outBuf.clear();

        IntBuffer inBuf1Int = inBuf1.asIntBuffer();
        IntBuffer inBuf2Int = inBuf2.asIntBuffer();
        IntBuffer outBufInt = outBuf.asIntBuffer();

        inBuf1Int.position(inBuf1Int.limit());
        inBuf2Int.position(inBuf2Int.limit());
        outBufInt.clear();
        while (true) {
            if (!inBuf1Int.hasRemaining()) {
                // if end of data run 1 is detected, break
                if (!in1.readBlock(inBuf1.array())) {
                    break;
                }
                inBuf1Int.rewind();
            }
            if (!inBuf2Int.hasRemaining()) {
                // same for data run 2
                if (!in2.readBlock(inBuf2.array())) {
                    break;
                }
                inBuf2Int.rewind();
            }

            mergeBlocks(inBuf1Int, inBuf2Int, outBufInt);

            // after merging, the output buffer might be full -> write to memory and clear
            if (!outBufInt.hasRemaining()) {
                out.write(outBuf.array());
                outBufInt.clear();
            }
        }

        // if one of the data runs is already empty, write remainder of the other data run to memory
        if (!in1.limitReached()) {
            writeRemainingBlocks(in1, inBuf1Int, outBufInt, outBuf);
        } else if (!in2.limitReached()) {
            writeRemainingBlocks(in2, inBuf2Int, outBufInt, outBuf);
        }
    }

    /**
     * is called when one of the data runs is already empty. The rest of the nonempty data run is written to the
     * output file
     * @param in
     * @param inBufInt
     * @param outBufInt
     * @param outBuf
     * @throws IOException
     */
    private void writeRemainingBlocks(LimitedStream in, IntBuffer inBufInt, IntBuffer outBufInt, ByteBuffer outBuf) throws IOException {
        while (inBufInt.hasRemaining()) {
            outBufInt.put(inBufInt.get());
        }
        if (!outBufInt.hasRemaining()) {
            out.write(outBuf.array());
        }
        outBufInt.clear();

        while (in.readBlock(outBuf.array())) {
            out.write(outBuf.array());
        }
    }

    /**
     * merges 2 input buffers until either one of them is empty, or the output buffer is full
     * @param inBuf1
     * @param inBuf2
     * @param outBuf
     */
    private void mergeBlocks(IntBuffer inBuf1, IntBuffer inBuf2, IntBuffer outBuf) {
        while (inBuf1.hasRemaining() && inBuf2.hasRemaining() && outBuf.hasRemaining()) {
            int x1 = inBuf1.get();
            int x2 = inBuf2.get();

            if (x1 <= x2) {
                outBuf.put(x1);
                inBuf2.position(inBuf2.position() - 1);
            } else {
                outBuf.put(x2);
                inBuf1.position(inBuf1.position() - 1);
            }
        }
    }

    /**
     * creates the initial data runs of size M using classical mergeSort
     * @throws IOException
     */
    private void createInitialRuns() throws IOException {
        byte[] byteArray;

        while ((byteArray = in1.readNBytes(M)).length > 0) {
            inBuf1 = ByteBuffer.wrap(byteArray);
            IntBuffer intBuf = inBuf1.asIntBuffer();
            int[] array = new int[intBuf.remaining()];
            intBuf.get(array);

            mergeSort(array);

            intBuf.clear();
            intBuf.put(array);
            out.write(inBuf1.array());
        }
    }

    private void openStreams(File inFile, File outFile) throws FileNotFoundException {
        in1 = new LimitedStream(new BufferedInputStream(new FileInputStream(inFile)));
        in2 = new LimitedStream(new BufferedInputStream(new FileInputStream(inFile)));
        out = new DataOutputStream(new BufferedOutputStream(new FileOutputStream(outFile)));
    }

    private void closeStreams() throws IOException {
        in1.close();
        in2.close();
        out.close();
    }

    /**
     * reads in the whole content of the file and sorts it, using classical mergeSort. The output is written to the
     * output file and the input file is deleted
     * @param inFileName
     * @param outFileName
     * @throws IOException
     */
    public static void mergeSortOnFile(String inFileName, String outFileName) throws IOException {
        File inFile = new File(inFileName);
        DataInputStream in = new DataInputStream(new BufferedInputStream(new FileInputStream(inFileName)));
        DataOutputStream out = new DataOutputStream(new BufferedOutputStream(new FileOutputStream(outFileName)));

        ByteBuffer buf = ByteBuffer.allocate((int) inFile.length());
        in.readFully(buf.array());

        int[] array = new int[buf.asIntBuffer().remaining()];
        buf.asIntBuffer().get(array);

        mergeSort(array);

        buf.asIntBuffer().put(array);
        out.write(buf.array());

        in.close();
        out.close();
    }

    public static void mergeSort(int[] a) {
        mergeSort(a, a.length);
    }

    /**
     * classical mergesort. After completion, the array a is sorted non-descendingly
     * @param a
     * @param n
     */
    public static void mergeSort(int[] a, int n) {
        int subArraySize;

        int start;

        for (subArraySize = 1; subArraySize <= n - 1;
             subArraySize *= 2) {

            for (start = 0; start < n - 1;
                 start += 2 * subArraySize)
            {
                int mid = Math.min(start + subArraySize - 1, n - 1);

                int end = Math.min(start
                        + 2 * subArraySize - 1, n - 1);
                merge(a, start, mid, end);
            }
        }
    }

    private static void merge(int[] a, int leftStart, int leftEnd, int rightEnd)
    {
        int i, j, k;
        int n1 = leftEnd - leftStart + 1;
        int n2 = rightEnd - leftEnd;

        int[] l = new int[n1]; // left array
        int[] r = new int[n2]; // right array

        for (i = 0; i < n1; i++) {
            l[i] = a[leftStart + i];
        }
        for (j = 0; j < n2; j++) {
            r[j] = a[leftEnd + 1 + j];
        }

        i = 0;
        j = 0;
        k = leftStart;
        while (i < n1 && j < n2) {
            if (l[i] <= r[j]) {
                a[k] = l[i];
                i++;
            } else {
                a[k] = r[j];
                j++;
            }
            k++;
        }

        while (i < n1) {
            a[k] = l[i];
            i++;
            k++;
        }

        while (j < n2) {
            a[k] = r[j];
            j++;
            k++;
        }
    }

    /**
     * sorts file with Arrays.sort() for comparison
     * @param inFileName
     * @param outFileName
     * @throws IOException
     */
    public static void sortFileComp(String inFileName, String outFileName) throws IOException {
        File inFile = new File(inFileName);
        DataInputStream in = new DataInputStream(new BufferedInputStream(new FileInputStream(inFileName)));
        DataOutputStream out = new DataOutputStream(new BufferedOutputStream(new FileOutputStream(outFileName)));

        ByteBuffer buf = ByteBuffer.allocate((int) inFile.length());
        in.readFully(buf.array());

        int[] array = new int[buf.asIntBuffer().remaining()];
        buf.asIntBuffer().get(array);

        Arrays.sort(array);

        buf.asIntBuffer().put(array);
        out.write(buf.array());

        in.close();
        out.close();
    }
}
