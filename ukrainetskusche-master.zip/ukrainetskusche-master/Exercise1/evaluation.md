# 1. General
* well done
* add a *more detailed* README file

# 2. Paper
## Abstract & Introduction
* good
* "MergeSort consists of two phases" -- there's more to it (divide & conquer)
* some pseudo-code would have been helpful

## Algorithm and Implementation
* very detailed, good


## Experimental Evaluation
* looks plausible
* do the results match the expected growth O(n log n) ?

## Conclusion
* as you noted correctly, one would expect in-memory MS to be significantly faster
* any ideas, why it doesn't show in your results?
* my *guess* is this: your EMM implementation is very efficient, but your classical implementation is not bc/ it wastes memory (see below)...

# 3. Code & Test Cases
* please add a README file explaining how to
  1. compile source code
  2. create test data
  3. run implementations with various arguments
* providing an idea project is a good start already
	* maybe implement your test cases using JUnit
	* would be quite convenient (for you to debug, for us to verify)

* source code is well structured and easy to read, good
* Sorter.java:
	* line 291,292: you are allocating temporary buffers in each call (old ones will be cleaned up by the GC)
	* it would be more efficient to work on just **two** buffers. Merge from one into the other, then switch roles --> no more wasted memory.
	 
* EM-Merge-Sort: file and buffer handling is very efficient, good
	* ByteBuffer.asIntBuffer() probably the smartest way to do this in Java

# 4. Assessment
Pass

