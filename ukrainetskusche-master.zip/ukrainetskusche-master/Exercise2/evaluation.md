# 1. General
* well done

# 2. Paper
## Abstract & Introduction
* good

## Algorithm and Implementation
* you won't reach O(n) but come close to O(n/p log n) (which you noted correctly in the end)
* Parallel Mergesort: the first (high-level) strategy is already effective on its own. The second (parallel-merging) strategy might improve results (but is not very effective on small inputs)
* it's great that you implemented both strategies 
* but there's room for improvement, see below

## Experimental Evaluation
* Mergesort ran out of memory with 10^9 elements? It shouldn't if you take care of memory allocations (like you did in the sequential implementation).
* nice figures
* from Figure 1 you can see that the second strategy on Mergesort is not very effective. It's only useful as an addition to the first strategy
* I guess there is some room for improvement on parallel Mergesort. It should be competitive with Quicksort. And it should beat sequential Mergesort on medium size inputs.


## Conclusion
* quite plausible


# 3. Code & Test Cases
* we would have liked a more detailed README file,  allowing use to run individual tests cases
* why not explain the JUnit test cases in the Readme?
  
* sequential merge-sort: looks good. You are using just one additional buffer.

* Parallel Quicksort: you keep splitting tasks all the way down to one element
	*  however: once all cores are busy there's no more benefit in creating tasks
	*  better: fall back to sequential implementation in lower levels of recursion
	*  parallel partitioning: good that you have implemented it. But again: there's no benefit to create more tasks than there are available cores..
	*  parallel partitioning is only useful in the upper levels of recursion (when some cores are idle)

* Parallel Mergesort: 
	* line 168: that's better: fall back to sequential.
	* parallel merging: not sure how many sub-blocks you use. Do you create a task for each entry? That would be grossly inefficient.
	* number of sub-blocks (for parallel merging)  should depend on the number of idle cores (which again depends on recursion level)

# 4. Assessment
Pass

