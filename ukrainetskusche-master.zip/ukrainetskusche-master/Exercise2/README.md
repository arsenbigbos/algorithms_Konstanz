To execute test case 1, run: java -Xms10g -Xmx16G -jar .\Experiment1.jar.
To execute test case 2, run: java -Xms10g -Xmx16G -jar .\Experiment2.jar.

The -Xms10g -Xmx16G is so the JVM doesn't run out of memory.
The results of the experiments are printed to the console.

The source code is in the ParallelSorting project. The content of Tester1.java corresponds to Experiment1.jar, the content of Tester2.java to to Experiment2.jar.